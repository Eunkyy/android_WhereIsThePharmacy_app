package ddwucom.mobile.finalproject.ma02_20200974;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<pharDTO> dataList;
    private LayoutInflater layoutInflater;

    public MyAdapter(Context context, int layout, ArrayList<pharDTO> myDataList) {
        this.context = context;
        this.layout = layout;
        this.layout = layout;
        this.dataList = myDataList;

        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public String allInfo() {
        return dataList.toString();
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public pharDTO getItem(int pos) {
        return dataList.get(pos);
    }

    @Override
    public long getItemId(int pos) {
        return dataList.get(pos).get_id();
    }

    public View getView(int pos, View convertView, ViewGroup viewGroup) {
        final int position = pos;
        ViewHolder viewHolder;int num;

        if (convertView == null) {
            convertView = layoutInflater.inflate(layout, viewGroup, false);

            viewHolder = new ViewHolder();
            viewHolder.addr = convertView.findViewById(R.id.addr);
            viewHolder.name = convertView.findViewById(R.id.name);
            viewHolder.tel = convertView.findViewById(R.id.tel0);

            convertView.setTag(viewHolder);

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.addr.setText(dataList.get(position).getDutyAddr());
        viewHolder.name.setText(dataList.get(position).getDutyName());
        viewHolder.tel.setText(dataList.get(position).getDutyTel1());

        return convertView;
    }

    static class ViewHolder {
        TextView addr;
        TextView name;
        TextView tel;
    }

}