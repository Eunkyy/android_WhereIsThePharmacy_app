package ddwucom.mobile.finalproject.ma02_20200974;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "likes_table")
public class MyPhar {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String name;
    public String tel;

    public MyPhar() {
    }

    public MyPhar(String name, String tel) {
        this.name = name;
        this.tel = tel;
    }

    @Override
    public String toString() {
        return "<즐겨찾기한 약국>\n"+
                " 약국 상호명='" + name + '\'' +
                ",\n tel='" + tel + " .";
    }
}
