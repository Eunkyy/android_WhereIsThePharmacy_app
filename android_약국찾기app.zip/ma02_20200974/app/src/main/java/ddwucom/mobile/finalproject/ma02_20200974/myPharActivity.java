package ddwucom.mobile.finalproject.ma02_20200974;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Flowable;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class myPharActivity extends AppCompatActivity {
    likesDB likesDb;
    likeDao likeDao;

    ListView listView;
    ArrayAdapter<MyPhar> adapter;

    private final CompositeDisposable mDisposable = new CompositeDisposable();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_phar);

        listView = findViewById(R.id.listView);
        adapter = new ArrayAdapter<MyPhar>(this, android.R.layout.simple_list_item_1, new ArrayList<MyPhar>());
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d(TAG, "id: " + listView.getAdapter().getItem(i));

                MyPhar delete = (MyPhar) listView.getAdapter().getItem(i);

                Completable deleteResult = likeDao.deleteFood(delete);
                mDisposable.add(deleteResult
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(() -> Log.d(TAG, "Delete success: "),
                                throwable -> Log.d(TAG, "error")) );

            }
        });

        likesDb = likesDB.getDatabase(this);
        likeDao = likesDb.likeDao();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDisposable.clear();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnShow:

                Flowable<List<MyPhar>> resultFoods = likeDao.getAllFoods();

                mDisposable.add( resultFoods
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(phars -> {
                                    for (MyPhar myPhar : phars) {
                                        Log.d(TAG, myPhar.toString());
                                    }
                                    adapter.clear();
                                    adapter.addAll(phars);
                                },
                                throwable -> Log.d(TAG, "error", throwable)) );
                break;
        }
    }
}