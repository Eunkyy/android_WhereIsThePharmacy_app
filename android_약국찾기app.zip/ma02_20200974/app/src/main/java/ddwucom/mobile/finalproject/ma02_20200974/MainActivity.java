package ddwucom.mobile.finalproject.ma02_20200974;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MainActivity";

    EditText et1;
    EditText et2;
    String apiAddress;
    String query1;
    String query2;

    ArrayList<pharDTO> resultList;
    apiParser parser;

    final int REQ_CODE = 100;
    final int VIEW_CODE = 200;

    ListView listView;
    MyAdapter myAdapter;
    //DiaryDBManager diaryDBManager;
    //DiaryDBHelper diaryDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = findViewById(R.id.et_Q0);
        et2 = findViewById(R.id.et_Q1);
        //diaryDBHelper = new DiaryDBHelper(this);
        listView = findViewById(R.id.customListView);
        //diaryDBManager = new DiaryDBManager(this);

        final int UPDATE_CODE = 200;

        resultList = new ArrayList();
        myAdapter = new MyAdapter(this, R.layout.info_item, resultList);
        listView.setAdapter(myAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pharDTO pharDTO = resultList.get(position);
                Intent intent = new Intent(MainActivity.this, Detail2Activity.class);
                intent.putExtra("pharDTO", pharDTO);
                startActivityForResult(intent, UPDATE_CODE);
            }
        });

        apiAddress = getResources().getString(R.string.api_url);
        parser = new apiParser();

        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return new java.security.cert.X509Certificate[]{};
            }

            @Override
            public void checkClientTrusted(
                    java.security.cert.X509Certificate[] chain,
                    String authType)
                    throws java.security.cert.CertificateException {
                // TODO Auto-generated method stub
            }

            @Override
            public void checkServerTrusted(
                    java.security.cert.X509Certificate[] chain,
                    String authType)
                    throws java.security.cert.CertificateException {
                // TODO Auto-generated method stub
            }
        }};

        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //롱클릭 코드 생략
    @Override
    protected void onResume() {
        super.onResume();

        //diaryDBManager.getAllDiary();
        myAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_CODE) {  // AddActivity 호출 후 결과 확인
            switch (resultCode) {
                case RESULT_OK:
                    String date = data.getStringExtra("date");
                    Toast.makeText(this, date + " 추가 완료", Toast.LENGTH_SHORT).show();
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "추가 취소", Toast.LENGTH_SHORT).show();
                    break;
            }
        } else if (requestCode == VIEW_CODE) {    // UpdateActivity 호출 후 결과 확인
            switch (resultCode) {
                case RESULT_OK:
                    String num = String.valueOf(data.getIntExtra("num", 10));
                    Toast.makeText(this, "디테일 정보 보기 완료", Toast.LENGTH_SHORT).show();
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "디테일 취소", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnSearch2:
                if (!isOnline()) {
                    Toast.makeText(MainActivity.this, "네트워크를 사용 설정해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                query1 = et1.getText().toString();
                new NaverAsyncTask().execute(apiAddress, query1);
                break;
        }
    }

    class NaverAsyncTask extends AsyncTask<String, Integer, String> {
        ProgressDialog progressDlg;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDlg = ProgressDialog.show(MainActivity.this, "Wait", "Downloading...");
        }

        @Override
        protected String doInBackground(String... strings) {

            Log.i(TAG, "hihi");
            String address = strings[0];
            String query = strings[1];
            String serviceKey = getResources().getString(R.string.client_id);

            String apiURL = null;
            try {
                apiURL = address;
               // apiURL = address + serviceKey+ "&Q0=서울특별시&Q1=강남구&QT=1&QN=삼성약국&ORD=NAME&pageNo=1&numOfRows=10";

                Log.i(TAG, apiURL);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String result = downloadContents(apiURL);
            return result;
        }


        @Override
        protected void onPostExecute(String result) {
            //Log.d(TAG, result);
            progressDlg.dismiss();
            if (result != null) {
                ArrayList<pharDTO> parserdList = parser.parse(result);     // 오픈API 결과의 파싱 수행

                if (parserdList == null || parserdList.size() == 0) {
                    Toast.makeText(MainActivity.this, "No data!", Toast.LENGTH_SHORT).show();
                } else {
                    resultList.clear();
                    resultList.addAll(parserdList);
                    myAdapter.notifyDataSetChanged();
                }
            }else{
                Log.d(TAG, "비었어");
            }
        }
    }

    /* 네트워크 환경 조사 */
    private boolean isOnline() {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }


    /* 주소(address)에 접속하여 문자열 데이터를 수신한 후 반환 */
    protected String downloadContents(String address) {
        String serviceKey = getResources().getString(R.string.client_id);
        String apiURL = null;
        query1 = et1.getText().toString();
        query2 = et1.getText().toString();
        try {
            apiURL = address + serviceKey + "&Q0="+ URLEncoder.encode(query1, "UTF-8")+ "&Q1="+ URLEncoder.encode(query2, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        Log.i(TAG, apiURL);
        HttpURLConnection conn = null;
        InputStream stream = null;
        String result = null;

        try {
            URL uri = new URL(apiURL); // service key is not registered 오류 방지
            Log.d(TAG, String.valueOf(uri));
            conn = (HttpURLConnection)uri.openConnection();
            conn.setRequestMethod("GET");
            if (conn == null)  Log.d(TAG, "망했다");
            else Log.d(TAG, "good");
            stream = getNetworkConnection(conn);
            Log.d(TAG, String.valueOf(stream));
            result = readStreamToString(stream);
            if (stream != null) stream.close();
        } catch (Exception e) {
            Log.d(TAG, "++");
            e.printStackTrace();
        } finally {
            if (conn != null) conn.disconnect();
        }

        Log.d(TAG, "Result: " + result);
        return result;
    }


    /* 주소(address)에 접속하여 비트맵 데이터를 수신한 후 반환 */
    protected Bitmap downloadImage(String address) {
        HttpURLConnection conn = null;
        InputStream stream = null;
        Bitmap result = null;

        try {
            URL url = new URL(address);
            conn = (HttpURLConnection)url.openConnection();
            stream = getNetworkConnection(conn);
            result = readStreamToBitmap(stream);
            if (stream != null) stream.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) conn.disconnect();
        }

        return result;
    }


    /* URLConnection 을 전달받아 연결정보 설정 후 연결, 연결 후 수신한 InputStream 반환 */
    private InputStream getNetworkConnection(HttpURLConnection conn) throws Exception {
        conn.setReadTimeout(3000);
        conn.setConnectTimeout(3000);
        conn.setRequestMethod("GET");
        conn.setDoInput(true);

        if (conn.getResponseCode() != HttpsURLConnection.HTTP_OK) {
            throw new IOException("HTTP error code: " + conn.getResponseCode());
        }

        return conn.getInputStream();
    }


    /* InputStream을 전달받아 문자열로 변환 후 반환 */
    protected String readStreamToString(InputStream stream){
        StringBuilder result = new StringBuilder();

        try {
            InputStreamReader inputStreamReader = new InputStreamReader(stream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            String readLine = bufferedReader.readLine();

            while (readLine != null) {
                result.append(readLine + "\n");
                readLine = bufferedReader.readLine();
            }

            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result.toString();
    }


    /* InputStream을 전달받아 비트맵으로 변환 후 반환 */
    protected Bitmap readStreamToBitmap(InputStream stream) {
        return BitmapFactory.decodeStream(stream);
    }



}