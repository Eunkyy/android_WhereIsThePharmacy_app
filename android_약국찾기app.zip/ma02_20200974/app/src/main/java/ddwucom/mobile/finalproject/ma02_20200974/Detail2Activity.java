package ddwucom.mobile.finalproject.ma02_20200974;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

public class Detail2Activity extends AppCompatActivity {

    TextView text;
    likesDB likesDb;
    likeDao dao;

    ListView listView;
    ArrayAdapter<MyPhar> adapter;
    pharDTO phar;
    private final CompositeDisposable mDisposable = new CompositeDisposable();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail2);
        likesDb = likesDB.getDatabase(this);
        dao = likesDb.likeDao();

        Intent intent = getIntent();
        phar = (pharDTO) intent.getSerializableExtra("pharDTO");
        text = findViewById(R.id.text);
        text.setText(phar.toString());
    }
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.likeBt:
                Single<Long> insertResult = dao.insertFood(new MyPhar(phar.getDutyName(), phar.getDutyTel1()));

                mDisposable.add (
                        insertResult.subscribeOn(Schedulers.io())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(result -> Log.d(TAG, "Insertion success: " + result),
                                        throwable -> Log.d(TAG, "error"))   );
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDisposable.clear();
    }
}