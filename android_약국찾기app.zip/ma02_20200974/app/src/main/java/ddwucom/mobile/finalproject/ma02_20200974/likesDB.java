package ddwucom.mobile.finalproject.ma02_20200974;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {MyPhar.class}, version=1)
public abstract class likesDB extends RoomDatabase {
    public abstract likeDao likeDao();

    private static volatile likesDB INSTANCE;

    static likesDB getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (likesDB.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    likesDB.class, "likes_db.db")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
