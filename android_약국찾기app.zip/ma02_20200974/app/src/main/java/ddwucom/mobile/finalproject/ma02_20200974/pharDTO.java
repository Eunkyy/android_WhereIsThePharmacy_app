package ddwucom.mobile.finalproject.ma02_20200974;

import android.text.Html;
import android.text.Spanned;

import java.io.Serializable;

public class pharDTO implements Serializable {


    private long _id;
    private String dutyAddr;
    private String dutyMapimg;
    private String dutyName;
    private String dutyTel1;
    private String dutyTime1c;
    private String dutyTime1s;
    private String dutyTime2c;
    private String dutyTime2s;
    private String dutyTime3c;
    private String dutyTime3s;
    private String dutyTime4c;
    private String dutyTime4s;
    private String dutyTime5c;
    private String dutyTime5s;
    private String dutyTime6c;
    private String dutyTime6s;
    private String dutyTime7c;
    private String dutyTime7s;
    private String dutyTime8c;
    private String dutyTime8s;

    public long get_id() {
        return _id;
    }

    public void set_id(long _id) {
        this._id = _id;
    }

    public String getDutyAddr() {
        return dutyAddr;
    }

    public void setDutyAddr(String dutyAddr) {
        this.dutyAddr = dutyAddr;
    }

    public String getDutyMapimg() {
        return dutyMapimg;
    }

    public void setDutyMapimg(String dutyMapimg) {
        this.dutyMapimg = dutyMapimg;
    }

    public String getDutyName() {
        return dutyName;
    }

    public void setDutyName(String dutyName) {
        this.dutyName = dutyName;
    }

    public String getDutyTel1() {
        return dutyTel1;
    }

    public void setDutyTel1(String dutyTel1) {
        this.dutyTel1 = dutyTel1;
    }

    public String getDutyTime1c() {
        return dutyTime1c;
    }

    public void setDutyTime1c(String dutyTime1c) {
        this.dutyTime1c = dutyTime1c;
    }

    public String getDutyTime1s() {
        return dutyTime1s;
    }

    public void setDutyTime1s(String dutyTime1s) {
        this.dutyTime1s = dutyTime1s;
    }

    public String getDutyTime2c() {
        return dutyTime2c;
    }

    public void setDutyTime2c(String dutyTime2c) {
        this.dutyTime2c = dutyTime2c;
    }

    public String getDutyTime2s() {
        return dutyTime2s;
    }

    public void setDutyTime2s(String dutyTime2s) {
        this.dutyTime2s = dutyTime2s;
    }

    public String getDutyTime3c() {
        return dutyTime3c;
    }

    public void setDutyTime3c(String dutyTime3c) {
        this.dutyTime3c = dutyTime3c;
    }

    public String getDutyTime3s() {
        return dutyTime3s;
    }

    public void setDutyTime3s(String dutyTime3s) {
        this.dutyTime3s = dutyTime3s;
    }

    public String getDutyTime4c() {
        return dutyTime4c;
    }

    public void setDutyTime4c(String dutyTime4c) {
        this.dutyTime4c = dutyTime4c;
    }

    public String getDutyTime4s() {
        return dutyTime4s;
    }

    public void setDutyTime4s(String dutyTime4s) {
        this.dutyTime4s = dutyTime4s;
    }

    public String getDutyTime5c() {
        return dutyTime5c;
    }

    public void setDutyTime5c(String dutyTime5c) {
        this.dutyTime5c = dutyTime5c;
    }

    public String getDutyTime5s() {
        return dutyTime5s;
    }

    public void setDutyTime5s(String dutyTime5s) {
        this.dutyTime5s = dutyTime5s;
    }

    public String getDutyTime6c() {
        return dutyTime6c;
    }

    public void setDutyTime6c(String dutyTime6c) {
        this.dutyTime6c = dutyTime6c;
    }

    public String getDutyTime6s() {
        return dutyTime6s;
    }

    public void setDutyTime6s(String dutyTime6s) {
        this.dutyTime6s = dutyTime6s;
    }

    public String getDutyTime7c() {
        return dutyTime7c;
    }

    public void setDutyTime7c(String dutyTime7c) {
        this.dutyTime7c = dutyTime7c;
    }

    public String getDutyTime7s() {
        return dutyTime7s;
    }

    public void setDutyTime7s(String dutyTime7s) {
        this.dutyTime7s = dutyTime7s;
    }

    public String getDutyTime8c() {
        return dutyTime8c;
    }

    public void setDutyTime8c(String dutyTime8c) {
        this.dutyTime8c = dutyTime8c;
    }

    public String getDutyTime8s() {
        return dutyTime8s;
    }

    public void setDutyTime8s(String dutyTime8s) {
        this.dutyTime8s = dutyTime8s;
    }

    @Override
    public String toString() {
        return "약국 세부설명:\n" +
                ",주소='" + dutyAddr + '\'' +
                ", 약도='" + dutyMapimg + '\'' +
                ", 상호명='" + dutyName + '\'' +
                ", 전화번호='" + dutyTel1 + '\'' +
                ", 월요일 닫는 시간='" + dutyTime1c + '\'' +
                ", 월요일 여는 시간='" + dutyTime1s + '\'' +
                ", 화요일 닫는 시간='" + dutyTime2c + '\'' +
                ", 화요일 여는 시간='" + dutyTime2s + '\'' +
                ", 수요일 닫는 시간='" + dutyTime3c + '\'' +
                ", 수요일 여는 시간='" + dutyTime3s + '\'' +
                ", 목요일 닫는 시간='" + dutyTime4c + '\'' +
                ", 목요일 여는 시간='" + dutyTime4s + '\'' +
                ", 금요일 닫는 시간='" + dutyTime5c + '\'' +
                ", 금요일 여는 시간='" + dutyTime5s + '\'' +
                ", 토요일 닫는 시간='" + dutyTime6c + '\'' +
                ", 토요일 여는 시간='" + dutyTime6s + '\'' +
                ", 일요일 닫는 시간='" + dutyTime7c + '\'' +
                ", 일요일 여는 시간='" + dutyTime7s + '\'' +
                ", 공휴일 닫는 시간='" + dutyTime8c + '\'' +
                ", 공휴일 여는 시간='" + dutyTime8s + '\'' +
                '}';
    }
}
