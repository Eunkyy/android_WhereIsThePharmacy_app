package ddwucom.mobile.finalproject.ma02_20200974;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.util.ArrayList;

public class apiParser {

    private enum TagType { none, dutyAddr, dutyMapimg, dutyName, dutyTel1, dutyTime1c, dutyTime2c, dutyTime3c, dutyTime4c, dutyTime5c, dutyTime6c, dutyTime7c, dutyTime8c, dutyTime1s, dutyTime2s, dutyTime3s, dutyTime4s, dutyTime5s, dutyTime6s, dutyTime7s, dutyTime8s};     // 해당없음, rank, movieNm, openDt, movieCd

    //    parsing 대상인 tag를 상수로 선언
    private final static String ITEM_TAG = "item";
    private final static String ADDR_TAG = "dutyAddr";
    private final static String MAPIMG_TAG = "dutyMapimg";
    private final static String NAME_TAG = "dutyName";
    private final static String TEL_TAG = "dutyTel1";
    private final static String TIME1C_TAG = "dutyTime1c";
    private final static String TIME2C_TAG = "dutyTime2c";
    private final static String TIME3C_TAG = "dutyTime3c";
    private final static String TIME4C_TAG = "dutyTime4c";
    private final static String TIME5C_TAG = "dutyTime5c";
    private final static String TIME6C_TAG = "dutyTime6c";
    private final static String TIME7C_TAG = "dutyTime7c";
    private final static String TIME8C_TAG = "dutyTime8c";
    private final static String TIME1S_TAG = "dutyTime1s";
    private final static String TIME2S_TAG = "dutyTime2s";
    private final static String TIME3S_TAG = "dutyTime3s";
    private final static String TIME4S_TAG = "dutyTime4s";
    private final static String TIME5S_TAG = "dutyTime5s";
    private final static String TIME6S_TAG = "dutyTime6s";
    private final static String TIME7S_TAG = "dutyTime7s";
    private final static String TIME8S_TAG = "dutyTime8s";

    private XmlPullParser parser;

    public apiParser() {
        try {
            parser = XmlPullParserFactory.newInstance().newPullParser();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<pharDTO> parse(String xml) {
        ArrayList<pharDTO> resultList = new ArrayList();
        pharDTO dbo = null;
        TagType tagType = TagType.none;     //  태그를 구분하기 위한 enum 변수 초기화

        try {
            parser.setInput(new StringReader(xml));

//            for (int eventType = parser.getEventType();
//                 eventType != XmlPullParser.END_DOCUMENT;
//                 eventType = parser.next())

            int eventType = parser.getEventType();      // 태그 유형 구분 변수 준비

            while (eventType != XmlPullParser.END_DOCUMENT) {  // parsing 수행 - for 문 또는 while 문으로 구성
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        break;
                    case XmlPullParser.START_TAG:
                        String tag = parser.getName();
                        if (tag.equals(ITEM_TAG)) {    // 새로운 항목을 표현하는 태그를 만났을 경우 dto 객체 생성
                            dbo = new pharDTO();
                        } else if (tag.equals(ADDR_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyAddr;
                        } else if (tag.equals(MAPIMG_TAG)) {
                            tagType = TagType.dutyMapimg;
                        } else if (tag.equals(NAME_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyName;
                        } else if (tag.equals(TEL_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyTel1;
                        } else if (tag.equals(TIME1C_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyTime1c;
                        }else if (tag.equals(TIME2C_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyTime2c ;
                        }else if (tag.equals(TIME3C_TAG )) {
                            if (dbo != null)
                                tagType = TagType.dutyTime3c;
                        }else if (tag.equals(TIME4C_TAG )) {
                            if (dbo != null)
                                tagType = TagType.dutyTime4c;
                        }else if (tag.equals(TIME5C_TAG )) {
                            if (dbo != null)
                                tagType = TagType.dutyTime5c;
                        }else if (tag.equals(TIME6C_TAG )) {
                            if (dbo != null)
                                tagType = TagType.dutyTime6c;
                        }else if (tag.equals(TIME7C_TAG )) {
                            if (dbo != null)
                                tagType = TagType.dutyTime7c;
                        }else if (tag.equals(TIME8C_TAG )) {
                            if (dbo != null)
                                tagType = TagType.dutyTime8c;
                        }else if (tag.equals(TIME1S_TAG )) {
                            if (dbo != null)
                                tagType = TagType.dutyTime1s;
                        }else if (tag.equals(TIME2S_TAG )) {
                            if (dbo != null)
                                tagType = TagType.dutyTime2s;
                        }else if (tag.equals(TIME3S_TAG )) {
                            if (dbo != null)
                                tagType = TagType.dutyTime3s;
                        }else if (tag.equals(TIME4S_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyTime4s;
                        }else if (tag.equals(TIME5S_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyTime5s;
                        }else if (tag.equals(TIME6S_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyTime6s;
                        }else if (tag.equals(TIME7S_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyTime7s;
                        }else if (tag.equals(TIME8S_TAG)) {
                            if (dbo != null)
                                tagType = TagType.dutyTime8s;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals(ITEM_TAG)) {
                            resultList.add(dbo);
                        }
                        break;
                    case XmlPullParser.TEXT:
                        switch(tagType) {       // 태그의 유형에 따라 dto 에 값 저장
                            case dutyAddr:
                                dbo.setDutyAddr(parser.getText());
                                break;
                            case dutyMapimg :
                                dbo.setDutyMapimg(parser.getText());
                                break;
                            case dutyName :
                                dbo.setDutyName(parser.getText());
                                break;
                            case dutyTel1 :
                                dbo.setDutyTel1(parser.getText());
                                break;
                            case dutyTime1c :
                                dbo.setDutyTime1c(parser.getText());
                                break;
                            case dutyTime2c :
                                dbo.setDutyTime2c(parser.getText());
                                break;
                            case dutyTime3c :
                                dbo.setDutyTime3c(parser.getText());
                                break;
                            case dutyTime4c :
                                dbo.setDutyTime4c(parser.getText());
                                break;
                            case dutyTime5c :
                                dbo.setDutyTime5c(parser.getText());
                                break;
                            case dutyTime6c :
                                dbo.setDutyTime6c(parser.getText());
                                break;
                            case dutyTime7c :
                                dbo.setDutyTime7c(parser.getText());
                                break;
                            case dutyTime8c :
                                dbo.setDutyTime8c(parser.getText());
                                break;
                            case dutyTime1s :
                                dbo.setDutyTime1s(parser.getText());
                                break;
                            case dutyTime2s :
                                dbo.setDutyTime2s(parser.getText());
                                break;
                            case dutyTime3s :
                                dbo.setDutyTime3s(parser.getText());
                                break;
                            case dutyTime4s :
                                dbo.setDutyTime4s(parser.getText());
                                break;
                            case dutyTime5s :
                                dbo.setDutyTime5s(parser.getText());
                                break;
                            case dutyTime6s :
                                dbo.setDutyTime6s(parser.getText());
                                break;
                            case dutyTime7s :
                                dbo.setDutyTime7s(parser.getText());
                                break;
                            case dutyTime8s :
                                dbo.setDutyTime8s(parser.getText());
                                break;
                        }
                        tagType = TagType.none;
                        break;
                }
                eventType = parser.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return resultList;
    }
}
